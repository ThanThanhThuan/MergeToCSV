﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace MergeToCSV
{
    public partial class Form1 : Form
    {
        private string fileUniCredit = "";
        private string fileMedioCredito = "";
        private string fileIfItalia = "";
        private string fileEuroFactor = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void btnUniCredit_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "xlsx files (*.xlsx)|*.xlsx";
          
            dlg.Title = "Please select a UniCredit file.";

            dlg.DefaultExt = ".xlsx"; // Default file extension 

            // Show open file dialog box 
            var result = dlg.ShowDialog();

            // Process open file dialog box results 
            if (result ==  DialogResult.OK)
            {
                fileUniCredit = dlg.FileName;
                this.txtUniCredit.Text= dlg.FileName;
                this.chkUniCredit.Checked = true;
            }
        }

        private void btnMedioCredito_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "xls files (*.xls)|*.xls";

            dlg.Title = "Please select a MedioCredito file.";

            dlg.DefaultExt = ".xls"; // Default file extension 

            // Show open file dialog box 
            var result = dlg.ShowDialog();

            // Process open file dialog box results 
            if (result == DialogResult.OK)
            {
                fileMedioCredito = dlg.FileName;
                this.txtMedioCredito.Text = dlg.FileName;
                this.chkMedioCredito.Checked = true;
            }
        }

        private void btnIfItalia_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "xls files (*.xls)|*.xls";

            dlg.Title = "Please select a IfItalia file.";

            dlg.DefaultExt = ".xls"; // Default file extension 

            // Show open file dialog box 
            var result = dlg.ShowDialog();

            // Process open file dialog box results 
            if (result == DialogResult.OK)
            {
                fileIfItalia = dlg.FileName;
                this.txtIfItalia.Text = dlg.FileName;
                this.chkIfItalia.Checked = true;
            }
        }

        private void btnEuroFactor_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "txt files (*.txt)|*.txt";

            dlg.Title = "Please select a EuroFactor file.";

            dlg.DefaultExt = ".txt"; // Default file extension 

            // Show open file dialog box 
            var result = dlg.ShowDialog();

            // Process open file dialog box results 
            if (result == DialogResult.OK)
            {
                fileEuroFactor = dlg.FileName;
                this.txtEuroFactor.Text = dlg.FileName;
                this.chkEuroFactor.Checked = true;
            }
        }
        private string GetFirstSheetName(string sconnectionString)
        {
            string res = "";
            var oleDbConnection = new OleDbConnection(sconnectionString);
            oleDbConnection.Open();
            DataTable dtSchema = oleDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
            // Use LINQ to get the table (i.e. sheet) names from the spreadsheet schema
            List<object> worksheets = (from dr in dtSchema.AsEnumerable()   // returns an IEnumerable<DataRow> collection
                                       select dr["TABLE_NAME"]).ToList();   // gets the sheet name from each schema entry

            foreach (string name in worksheets)
            {
                if (!name.StartsWith("_"))
                {
                   res = "[" + name + "]";
                    break;
                }
            }
            oleDbConnection.Close();
            return res;
        }
        private void btnMerge_Click(object sender, EventArgs e)
        {
            bool appendOK = false;
            try
            {
                File.WriteAllText("output.csv", "");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
          
         
            if (fileUniCredit != "" && chkUniCredit.Checked)
            {
                var sconnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + fileUniCredit + "';Extended Properties=\"Excel 12.0;HDR=YES;\"";

                var sheet1 = GetFirstSheetName(sconnectionString);

                //var connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = '" + fileUniCredit + "';Extended Properties=\"Excel 8.0;HDR=YES;\"";
                // Connect EXCEL sheet with OLEDB using connection string
                using (OleDbConnection conn = new OleDbConnection(sconnectionString))
                {
                    conn.Open();
                    // Sheet1$
                    OleDbDataAdapter objDA = new System.Data.OleDb.OleDbDataAdapter
                    ("select * from " + sheet1, conn);
                    //("select * from [Scarico Dati WOF$]", conn);
                    DataSet excelDataSet = new DataSet();
                    objDA.Fill(excelDataSet);
                    conn.Close();
                    //Ndg Anagrafica  Codice linea    Linea di sistema Linea di credito    Registrazione Emissione   Tipo Numero  Gamma Rata    Divisa Facciale    Residuo oustanding  Residuo c/ cessione  Scadenza emittente  Scadenza debitore   Maturity Mezzo incasso Chiusura    Riconoscimento Contestazione   Preavvisata Vs codice cliente
                    //0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15  16  17  18  19  20  21  22  23
                    //416820  AR.CO.S.R.L.   571 ANTICIPO PUTO AZIENDE PRIVATE   395306  09 / 06 / 2022  31 / 05 / 2022  RTC 2031004838      1   EUR 6,362.88    0.00    0.00    31 / 07 / 2022  31 / 07 / 2022      RBE 01 / 08 / 2022          N   1001246

                    //res =200,2320,2022,2031004838,20220801,6362.88,+,UC

                    var dt = excelDataSet.Tables[0];
                    int firstRow = 0;
                    for (int i = 0; i < 15; i++)
                    {
                        if (dt.Rows[i].ItemArray[0].ToString().ToLower() == "ndg")
                        {
                            firstRow = i + 1;
                            break;
                        }
                    }
                    StringBuilder sb = new StringBuilder();
                    for (int i = firstRow; i < dt.Rows.Count; i++)
                    {
                        string Col1 = "200";
                        string Col2 = "2320";
                        string Col3 = "";
                        string Col4 = "";
                        string Col5 = "";
                        string Col6 = "";
                        string Col7 = "";
                        string Col8 = "UC"; //UniCredit
                        string ColA = "";
                        string ColB = "";
                        string ColC = "";
                        string ColD = "";
                      
                        Col4 = dt.Rows[i].ItemArray[8].ToString();
//                        Column 9 “Numero” (2031004838, 2031005675, 2031002820, …)  A
//Column 7 “Emissione” extract year from date (2023, 2022, 2021, …)  B
//Column 13 “Facciale” (6.362, 88, 6.811, 80, 37332, …)  C
//Column 20 “Chiusura” (01 / 08 / 2022, 12 / 08 / 2022, 11 / 07 / 2022, …)  D


                        // 5=Registrazione ,  6=Emissione

                        Col3 = Convert.ToDateTime(dt.Rows[i].ItemArray[6]).ToString("yyyy");
                        var D_REG = Convert.ToDateTime(dt.Rows[i].ItemArray[19]).ToString("yyyyMMdd"); //23/12/2021
                                                                                                      //5° column  Data from D(convert date from dd/ mm / yyyy to yyyymmdd)
                        Col5 = D_REG;
                    
                        double imp0 = Convert.ToDouble(dt.Rows[i].ItemArray[12].ToString().Trim());
                        //6° column  Data from C(the decimal separator should be dot “.” instead coma “,”)
                        Col6 = Math.Abs(imp0).ToString().Replace(",", ".");
                        if (Col6.EndsWith("."))
                        {
                            Col6 += "0";
                        }
                        //7° column  Data from C(if the value is positive, then “+”, if it’s negative, then “-”)
                        Col7 = imp0>=0 ? "+" : "-";

                        //Codice Cliente	Ragione Sociale	Cod. Deb. Ifitalia	Linea di Credito	Numero Documento	Descrizione causale	Data Valuta	Divisa	Importo	Gamma	Dato Supplementare	Data Contabile	Data Scadenza Fattura	Data Emissione	Cod. Causale
                        //6581    MULTI COLOR ITALIA S P A    0321007 0116837 203110678   ACCREDITO SBF   31 / 12 / 2021  EUR + 5,919.38           31 / 12 / 2021  31 / 12 / 2021  09 / 09 / 2021  0352
                        //res = 200,2320,2021,203110678,20211231,5919.38,+,IF
                        //var n = i == dt.Rows.Count - 1 ? "" : "\n";
                        sb.Append(Col1 + "," + Col2 + "," + Col3 + "," + Col4 + "," + Col5 + "," + Col6 + "," + Col7 + "," + Col8 + "\n");
                    }
                    try
                    {
                        File.AppendAllText("output.csv", sb.ToString());
                        appendOK = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                     
                    }
                
                }
            }
            if (fileMedioCredito != "" && chkMedioCredito.Checked)
            {

                // Connect EXCEL sheet with OLEDB using connection string
            
               var sconnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + fileMedioCredito + "';Extended Properties=\"Excel 12.0;HDR=YES;\"";
                var sheet1 = GetFirstSheetName(sconnectionString);
                //var connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = '" + fileMedioCredito + "';Extended Properties=\"Excel 8.0;HDR=YES;\"";
                // Connect EXCEL sheet with OLEDB using connection string
                using (OleDbConnection conn = new OleDbConnection(sconnectionString))
                {
                    conn.Open();
                    // Sheet1$
                    OleDbDataAdapter objDA = new System.Data.OleDb.OleDbDataAdapter
                    ("select * from " + sheet1, conn);
                    DataSet excelDataSet = new DataSet();
                    objDA.Fill(excelDataSet);
                    conn.Close();
                    //CODICE NUMERO CONTO: DATA REGISTRAZIONE :	TIPO MOVIMENTO  NR.RIFERIMENTO MF   DATA DOCUMENTO  NUMERO DOCUMENTO    PROGRESSIVO DOCUMENTO   DATA VALUTA IMPORTO DARE    IMPORTO AVERE
                    //0   1   2   3   4   5   6   7   8   9   10
                    //398522062   01.10.001   17 / 01 / 2022  Importo movimentato[BONIF.DEBITORE]     2021    0000000203110639        15 / 01 / 2022      3489.66
                    //res =200,2320,2021,203110639,20220117,3489.66,+,MC

                    var dt = excelDataSet.Tables[0];
                    int firstRow = 0;
                    for (int i = 0; i < 15; i++)
                    {
                        if (dt.Rows[i].ItemArray[0].ToString().ToLower() == "codice")
                        {
                            firstRow = i + 1;
                            break;
                        }
                    }
                    StringBuilder sb = new StringBuilder();
                    for (int i = firstRow; i < dt.Rows.Count; i++)
                    {
                        string Col1 = "200";
                        string Col2 = "2320";
                        string Col3 = "";
                        string Col4 = "";
                        string Col5 = "";
                        string Col6 = "";
                        string Col7 = "";
                        string Col8 = "MC"; //MedioCredito
                        string ColA = "";
                        string ColB = "";
                        string ColC = "";
                        string ColD = "";
//                        Column G -> 6“NUMERO DOCUMENTO” (0000000203110639, 0000000203110926, 0000000203110968, …)  A
//Column F-5 “DATA DOCUMENTO” (2023, 2022, 2021, …)  B
//Column K “IMPORTO AVERE” or J “COLUMN DARE” with minus sign(3489, 66, 11556, 11, -669662, 19, …)  C
//Column C-2 “DATA REGISTRAZIONE” (17 / 01 / 2022, 07 / 02 / 2022, 16 / 02 / 2022, …)  D

                        //0000000203110639 [6]
                        Col4 = Convert.ToInt64(dt.Rows[i].ItemArray[6].ToString().Trim()).ToString();
                       
                        Col3 = dt.Rows[i].ItemArray[5].ToString().Trim();
                        //=Col C
                        var D_REG = Convert.ToDateTime(dt.Rows[i].ItemArray[2]).ToString("yyyyMMdd"); //23/12/2021
                                                                                                       //5° column  Data from D(convert date from dd/ mm / yyyy to yyyymmdd)
                        Col5 = D_REG;
                        //9 = Nega, 10 = Posi
                        double imp0 = 0;
                        bool isPositive = true;
                        if (dt.Rows[i].ItemArray[9].ToString()=="")
                        {
                            imp0 = Convert.ToDouble(dt.Rows[i].ItemArray[10].ToString().Trim());
                        }
                        else
                        {
                            imp0 = Convert.ToDouble(dt.Rows[i].ItemArray[9].ToString().Trim());
                            isPositive = false;
                        }
                       
                        //6° column  Data from C(the decimal separator should be dot “.” instead coma “,”)
                        Col6 = Math.Abs(imp0).ToString().Replace(",", ".");
                        if (Col6.EndsWith("."))
                        {
                            Col6 += "0";
                        }
                        //7° column  Data from C(if the value is positive, then “+”, if it’s negative, then “-”)
                        Col7 = isPositive ? "+" : "-";

                        //Codice Cliente	Ragione Sociale	Cod. Deb. Ifitalia	Linea di Credito	Numero Documento	Descrizione causale	Data Valuta	Divisa	Importo	Gamma	Dato Supplementare	Data Contabile	Data Scadenza Fattura	Data Emissione	Cod. Causale
                        //6581    MULTI COLOR ITALIA S P A    0321007 0116837 203110678   ACCREDITO SBF   31 / 12 / 2021  EUR + 5,919.38           31 / 12 / 2021  31 / 12 / 2021  09 / 09 / 2021  0352
                        //res = 200,2320,2021,203110678,20211231,5919.38,+,IF
                        //var n = i == dt.Rows.Count - 1 ? "" : "\n";
                        sb.Append(Col1 + "," + Col2 + "," + Col3 + "," + Col4 + "," + Col5 + "," + Col6 + "," + Col7 + "," + Col8 + "\n");
                    }
                 
                    try
                    {
                        File.AppendAllText("output.csv", sb.ToString());
                        appendOK = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);

                    }
                }
            }
            //------------------------
            if (fileIfItalia != "" && chkIfItalia.Checked)
            {

                // Connect EXCEL sheet with OLEDB using connection string
                var sconnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + fileIfItalia + "';Extended Properties=\"Excel 12.0;HDR=YES;\"";
                var sheet1 = GetFirstSheetName(sconnectionString);
                //var connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source = '" + fileIfItalia + "';Extended Properties=\"Excel 8.0;HDR=YES;\"";
            // Connect EXCEL sheet with OLEDB using connection string
            using (OleDbConnection conn = new OleDbConnection(sconnectionString))
            {
                conn.Open();
               // Sheet1$
                OleDbDataAdapter objDA = new System.Data.OleDb.OleDbDataAdapter
                ("select * from " + sheet1  , conn);
                DataSet excelDataSet = new DataSet();
                objDA.Fill(excelDataSet);
                conn.Close();
                //dataGridView1.DataSource = excelDataSet.Tables[0];
                //                ?excelDataSet.Tables[0].Rows[4].ItemArray[0]
                //"Codice Cliente"
             
                var dt = excelDataSet.Tables[0];
                int firstRow = 0;
                    //                        XLS file, skip the first 5 lines
                    for (int i = 0; i < 15; i++)
                {
                    if (dt.Rows[i].ItemArray[0].ToString().ToLower()== "codice cliente")
                    {
                        firstRow = i+1;
                        break;
                        }
                }
                StringBuilder sb = new StringBuilder();
                for (int i = firstRow; i < dt.Rows.Count; i++)
                {
                    string Col1 = "200";
                    string Col2 = "2320";
                    string Col3 = "";
                    string Col4 = "";
                    string Col5 = "";
                    string Col6 = "";
                    string Col7 = "";
                    string Col8 = "IF"; //from ifitalia.xls, then IF 
                    string ColA = "";
                    string ColB = "";
                    string ColC = "";
                    string ColD = "";

//Column E-4 “Numero Documento” (203110678, 203110840, 203111053, …)  A
//Column N-13 “Data Emissone” extract year from date (2023, 2022, 2021, …)  B
//Column I-8 “Importo” (5919, 38, 1282, 77, 10132, 56, …)  C
//Column L-11 “Data Contabile” (31 / 12 / 2021, 31 / 05 / 2022, 31 / 03 / 2022, …)  D

                    Col4 = dt.Rows[i].ItemArray[4].ToString().Trim();
                    var D_FAT = Convert.ToDateTime(dt.Rows[i].ItemArray[13]).ToString("yyyy"); //23/12/2021
                    ColB = D_FAT;
                    //3° column  Data from B
                    Col3 = ColB;
                    var D_REG = Convert.ToDateTime(dt.Rows[i].ItemArray[11]).ToString("yyyyMMdd"); //23/12/2021
                    //5° column  Data from D(convert date from dd/ mm / yyyy to yyyymmdd)
                    Col5 = D_REG;

                    //+5,919.38 [8]
                    var imp0 = Convert.ToDouble(dt.Rows[i].ItemArray[8].ToString().Trim());
                    //6° column  Data from C(the decimal separator should be dot “.” instead coma “,”)
                    Col6 = Math.Abs(imp0).ToString().Replace(",",".");
                    if (Col6.EndsWith("."))
                    {
                        Col6 += "0";
                    }
                    //7° column  Data from C(if the value is positive, then “+”, if it’s negative, then “-”)
                    Col7 = imp0 >= 0 ? "+" : "-";

                    //Codice Cliente	Ragione Sociale	Cod. Deb. Ifitalia	Linea di Credito	Numero Documento	Descrizione causale	Data Valuta	Divisa	Importo	Gamma	Dato Supplementare	Data Contabile	Data Scadenza Fattura	Data Emissione	Cod. Causale
                    //6581    MULTI COLOR ITALIA S P A    0321007 0116837 203110678   ACCREDITO SBF   31 / 12 / 2021  EUR + 5,919.38           31 / 12 / 2021  31 / 12 / 2021  09 / 09 / 2021  0352
                    //res = 200,2320,2021,203110678,20211231,5919.38,+,IF
                    //var n = i == dt.Rows.Count - 1 ? "" : "\n";
                    sb.Append(Col1 + "," + Col2 + "," + Col3 + "," + Col4 + "," + Col5 + "," + Col6 + "," + Col7 + "," + Col8 + "\n");
                }
              
                    try
                    {
                        File.AppendAllText("output.csv", sb.ToString());
                        appendOK = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);

                    }
                }
            }
            // return;

            if (fileEuroFactor!="" && chkEuroFactor.Checked)
            {
                //                eurofactor.txt 20
                //TXT file, filed separated by #
                //Skip the rows with the column “FATTURA” empty(skip last line)
         
                // src = CARTOLIANZA S.R.L. #010158746#0001001098#21-3115052
                // #0000031922,52#05/04/2022#EUR#+000015961,26
                // #12/04/2022#06/04/2022#23/12/2021#02#

                //OUT = 200,2320,2021,203115052,20220406,15961.26,+,EF
                //------
                //                CSV file, coma separated without header
                //1° column  Always string “200”
                //2° column  Always string “2320”
                string Col1 = "200";
                string Col2 = "2320";
                string Col3 = "";
                string Col4 = "";
                string Col5 = "";
                string Col6 = "";
                string Col7 = "";
                string Col8 = "EF";
                string ColA = "";
                string ColB = "";
                string ColC = "";
                string ColD = "";
                StringBuilder sb = new StringBuilder();
                var lines = File.ReadAllLines(fileEuroFactor);
                for (int i = 0; i < lines.Count(); i++)
                {
                    if (i>0 && i<lines.Count()-1 && lines[i].Trim()!="")
                    {
                        var lineps = lines[i].Trim().Split('#');
                        //Column “FATTURA” (21-3115052, 21 - 3114232, 21 - 3114232, …)  A
                        ColA = lineps[3].Trim();
                        //4° column  Data from A
                        Col4 = "20" + ColA.Split('-')[1];
                        //Column “D.FAT” extract year from date (2023, 2022, 2021, …)  B
                        var D_FAT = lineps[10].Trim(); //23/12/2021
                        ColB = D_FAT.Substring(6);
                        //3° column  Data from B
                        Col3 = ColB;
                        //Column “IMP.INCASSO” (15961, 26, 3462, 58, -3462, 58, …)  C
                        var IMP_INCASSO = Convert.ToDouble(lineps[7].Trim().Replace(",",".")); //+000015961,26
                        //var imps = IMP_INCASSO.Split(',');
                        //var imp0 = Convert.ToInt32(imps[0]);
                        //var imp1 = "";
                        //if (imps.Length>1)
                        //{
                        //    imp1 = "." + imps[1];
                        //}
                        //6° column  Data from C(the decimal separator should be dot “.” instead coma “,”)
                        Col6 = Math.Abs(IMP_INCASSO).ToString().Replace(",", ".");
                        if (Col6.EndsWith("."))
                        {
                            Col6 += "0";
                        }
                        //7° column  Data from C(if the value is positive, then “+”, if it’s negative, then “-”)
                        Col7 = IMP_INCASSO >= 0 ? "+" : "-";
                        //Column “D.REG” (12/04/2022, 10 / 04 / 2022, 19 / 04 / 2022, …)  D
                        var D_REG = lineps[9].Trim();
                        //5° column  Data from D(convert date from dd/ mm / yyyy to yyyymmdd)
                        Col5 = D_REG.Substring(6,4) + D_REG.Substring(3,2) + D_REG.Substring(0,2);
                       
                        //8° column  If the record comes from eurofactor.txt, then EF – If from ifitalia.xls, then IF -If from mediocredito.xls, then MC – If from unicredit.xlsx, then UC
                        var n = i == lines.Count() - 2 ? "" : "\n";
                        sb.Append(Col1 + "," + Col2 + "," + Col3 + "," + Col4 + "," + Col5 + "," + Col6 + "," + Col7 + "," + Col8 + n);
                       // var h = "";
                    }
                }
                
                try
                {
                    File.AppendAllText("output.csv", sb.ToString());
                    appendOK = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }
            //MessageBox.Show("Merged to file: " + System.Windows.Forms.Application.StartupPath + "\\output.csv");
            if (appendOK)
            {
                var res = MessageBox.Show("Merged to file: " + System.Windows.Forms.Application.StartupPath + "\\output.csv. Do you want to open it?", "Output", MessageBoxButtons.YesNo);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath + "\\output.csv");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
            
        }

        private void txtUniCredit_Leave(object sender, EventArgs e)
        {
            if (txtUniCredit.Text.Trim().ToLower() != fileUniCredit.ToLower())
            {
                if (txtUniCredit.Text.Trim().ToLower().EndsWith("xlsx") && File.Exists(txtUniCredit.Text.Trim()))
                {
                    fileUniCredit = txtUniCredit.Text.Trim();
                }
                else
                {
                    MessageBox.Show("Invalid file UniCredit.");
                    txtUniCredit.Text = fileUniCredit;
                }
            }
        }

        private void txtMedioCredito_Leave(object sender, EventArgs e)
        {
            if (txtMedioCredito.Text.Trim().ToLower() != fileMedioCredito.ToLower())
            {
                if (txtMedioCredito.Text.Trim().ToLower().EndsWith("xls") && File.Exists(txtMedioCredito.Text.Trim()))
                {
                    fileMedioCredito = txtMedioCredito.Text.Trim();
                }
                else
                {
                    MessageBox.Show("Invalid file MedioCredito.");
                    txtMedioCredito.Text = fileMedioCredito;
                }
            }
        }

        private void txtIfItalia_Leave(object sender, EventArgs e)
        {
            if (txtIfItalia.Text.Trim().ToLower() != fileIfItalia.ToLower())
            {
                if (txtIfItalia.Text.Trim().ToLower().EndsWith("xls") && File.Exists(txtIfItalia.Text.Trim()))
                {
                    fileIfItalia = txtIfItalia.Text.Trim();
                }
                else
                {
                    MessageBox.Show("Invalid file IfItalia.");
                    txtIfItalia.Text = fileIfItalia;
                }
            }
        }

        private void txtEuroFactor_Leave(object sender, EventArgs e)
        {
            if (txtEuroFactor.Text.Trim().ToLower() != fileEuroFactor.ToLower())
            {
                if (txtEuroFactor.Text.Trim().ToLower().EndsWith("txt") && File.Exists(txtEuroFactor.Text.Trim()))
                {
                    fileEuroFactor = txtEuroFactor.Text.Trim();
                }
                else
                {
                    MessageBox.Show("Invalid file EuroFactor.");
                    txtEuroFactor.Text = fileEuroFactor;
                }
            }
        }
    }
}
