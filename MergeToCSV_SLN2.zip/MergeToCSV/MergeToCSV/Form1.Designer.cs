﻿namespace MergeToCSV
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnUniCredit = new System.Windows.Forms.Button();
            this.txtUniCredit = new System.Windows.Forms.TextBox();
            this.chkUniCredit = new System.Windows.Forms.CheckBox();
            this.chkMedioCredito = new System.Windows.Forms.CheckBox();
            this.txtMedioCredito = new System.Windows.Forms.TextBox();
            this.btnMedioCredito = new System.Windows.Forms.Button();
            this.btnEuroFactor = new System.Windows.Forms.Button();
            this.chkEuroFactor = new System.Windows.Forms.CheckBox();
            this.txtEuroFactor = new System.Windows.Forms.TextBox();
            this.chkIfItalia = new System.Windows.Forms.CheckBox();
            this.txtIfItalia = new System.Windows.Forms.TextBox();
            this.btnIfItalia = new System.Windows.Forms.Button();
            this.btnMerge = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnUniCredit
            // 
            this.btnUniCredit.Location = new System.Drawing.Point(29, 39);
            this.btnUniCredit.Name = "btnUniCredit";
            this.btnUniCredit.Size = new System.Drawing.Size(261, 32);
            this.btnUniCredit.TabIndex = 0;
            this.btnUniCredit.Text = "Select file UniCredit";
            this.btnUniCredit.UseVisualStyleBackColor = true;
            this.btnUniCredit.Click += new System.EventHandler(this.btnUniCredit_Click);
            // 
            // txtUniCredit
            // 
            this.txtUniCredit.Location = new System.Drawing.Point(306, 45);
            this.txtUniCredit.Name = "txtUniCredit";
            this.txtUniCredit.Size = new System.Drawing.Size(581, 22);
            this.txtUniCredit.TabIndex = 1;
            this.txtUniCredit.Leave += new System.EventHandler(this.txtUniCredit_Leave);
            // 
            // chkUniCredit
            // 
            this.chkUniCredit.AutoSize = true;
            this.chkUniCredit.Location = new System.Drawing.Point(910, 47);
            this.chkUniCredit.Name = "chkUniCredit";
            this.chkUniCredit.Size = new System.Drawing.Size(55, 20);
            this.chkUniCredit.TabIndex = 2;
            this.chkUniCredit.Text = "Pick";
            this.chkUniCredit.UseVisualStyleBackColor = true;
            // 
            // chkMedioCredito
            // 
            this.chkMedioCredito.AutoSize = true;
            this.chkMedioCredito.Location = new System.Drawing.Point(909, 109);
            this.chkMedioCredito.Name = "chkMedioCredito";
            this.chkMedioCredito.Size = new System.Drawing.Size(55, 20);
            this.chkMedioCredito.TabIndex = 4;
            this.chkMedioCredito.Text = "Pick";
            this.chkMedioCredito.UseVisualStyleBackColor = true;
            // 
            // txtMedioCredito
            // 
            this.txtMedioCredito.Location = new System.Drawing.Point(305, 107);
            this.txtMedioCredito.Name = "txtMedioCredito";
            this.txtMedioCredito.Size = new System.Drawing.Size(581, 22);
            this.txtMedioCredito.TabIndex = 3;
            this.txtMedioCredito.Leave += new System.EventHandler(this.txtMedioCredito_Leave);
            // 
            // btnMedioCredito
            // 
            this.btnMedioCredito.Location = new System.Drawing.Point(26, 100);
            this.btnMedioCredito.Name = "btnMedioCredito";
            this.btnMedioCredito.Size = new System.Drawing.Size(261, 32);
            this.btnMedioCredito.TabIndex = 5;
            this.btnMedioCredito.Text = "Select file MedioCredito";
            this.btnMedioCredito.UseVisualStyleBackColor = true;
            this.btnMedioCredito.Click += new System.EventHandler(this.btnMedioCredito_Click);
            // 
            // btnEuroFactor
            // 
            this.btnEuroFactor.Location = new System.Drawing.Point(23, 224);
            this.btnEuroFactor.Name = "btnEuroFactor";
            this.btnEuroFactor.Size = new System.Drawing.Size(261, 32);
            this.btnEuroFactor.TabIndex = 11;
            this.btnEuroFactor.Text = "Select file EuroFactor";
            this.btnEuroFactor.UseVisualStyleBackColor = true;
            this.btnEuroFactor.Click += new System.EventHandler(this.btnEuroFactor_Click);
            // 
            // chkEuroFactor
            // 
            this.chkEuroFactor.AutoSize = true;
            this.chkEuroFactor.Location = new System.Drawing.Point(906, 233);
            this.chkEuroFactor.Name = "chkEuroFactor";
            this.chkEuroFactor.Size = new System.Drawing.Size(55, 20);
            this.chkEuroFactor.TabIndex = 10;
            this.chkEuroFactor.Text = "Pick";
            this.chkEuroFactor.UseVisualStyleBackColor = true;
            // 
            // txtEuroFactor
            // 
            this.txtEuroFactor.Location = new System.Drawing.Point(302, 231);
            this.txtEuroFactor.Name = "txtEuroFactor";
            this.txtEuroFactor.Size = new System.Drawing.Size(581, 22);
            this.txtEuroFactor.TabIndex = 9;
            this.txtEuroFactor.Leave += new System.EventHandler(this.txtEuroFactor_Leave);
            // 
            // chkIfItalia
            // 
            this.chkIfItalia.AutoSize = true;
            this.chkIfItalia.Location = new System.Drawing.Point(907, 171);
            this.chkIfItalia.Name = "chkIfItalia";
            this.chkIfItalia.Size = new System.Drawing.Size(55, 20);
            this.chkIfItalia.TabIndex = 8;
            this.chkIfItalia.Text = "Pick";
            this.chkIfItalia.UseVisualStyleBackColor = true;
            // 
            // txtIfItalia
            // 
            this.txtIfItalia.Location = new System.Drawing.Point(303, 169);
            this.txtIfItalia.Name = "txtIfItalia";
            this.txtIfItalia.Size = new System.Drawing.Size(581, 22);
            this.txtIfItalia.TabIndex = 7;
            this.txtIfItalia.Leave += new System.EventHandler(this.txtIfItalia_Leave);
            // 
            // btnIfItalia
            // 
            this.btnIfItalia.Location = new System.Drawing.Point(26, 163);
            this.btnIfItalia.Name = "btnIfItalia";
            this.btnIfItalia.Size = new System.Drawing.Size(261, 32);
            this.btnIfItalia.TabIndex = 6;
            this.btnIfItalia.Text = "Select file IfItalia";
            this.btnIfItalia.UseVisualStyleBackColor = true;
            this.btnIfItalia.Click += new System.EventHandler(this.btnIfItalia_Click);
            // 
            // btnMerge
            // 
            this.btnMerge.Location = new System.Drawing.Point(471, 299);
            this.btnMerge.Name = "btnMerge";
            this.btnMerge.Size = new System.Drawing.Size(172, 56);
            this.btnMerge.TabIndex = 12;
            this.btnMerge.Text = "Merge";
            this.btnMerge.UseVisualStyleBackColor = true;
            this.btnMerge.Click += new System.EventHandler(this.btnMerge_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 517);
            this.Controls.Add(this.btnMerge);
            this.Controls.Add(this.btnEuroFactor);
            this.Controls.Add(this.chkEuroFactor);
            this.Controls.Add(this.txtEuroFactor);
            this.Controls.Add(this.chkIfItalia);
            this.Controls.Add(this.txtIfItalia);
            this.Controls.Add(this.btnIfItalia);
            this.Controls.Add(this.btnMedioCredito);
            this.Controls.Add(this.chkMedioCredito);
            this.Controls.Add(this.txtMedioCredito);
            this.Controls.Add(this.chkUniCredit);
            this.Controls.Add(this.txtUniCredit);
            this.Controls.Add(this.btnUniCredit);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Merge to CSV";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUniCredit;
        private System.Windows.Forms.TextBox txtUniCredit;
        private System.Windows.Forms.CheckBox chkUniCredit;
        private System.Windows.Forms.CheckBox chkMedioCredito;
        private System.Windows.Forms.TextBox txtMedioCredito;
        private System.Windows.Forms.Button btnMedioCredito;
        private System.Windows.Forms.Button btnEuroFactor;
        private System.Windows.Forms.CheckBox chkEuroFactor;
        private System.Windows.Forms.TextBox txtEuroFactor;
        private System.Windows.Forms.CheckBox chkIfItalia;
        private System.Windows.Forms.TextBox txtIfItalia;
        private System.Windows.Forms.Button btnIfItalia;
        private System.Windows.Forms.Button btnMerge;
    }
}

